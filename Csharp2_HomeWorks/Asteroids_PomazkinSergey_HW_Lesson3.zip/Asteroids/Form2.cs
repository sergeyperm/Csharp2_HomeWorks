﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;

namespace Asteroids
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            timer1.Interval = 500; // 50 миллисекунд
            timer1.Enabled = true;
            timer1.Start();
            timer1.Tick += Timer1_Tick;

        }
        private void Timer1_Tick(object sender, EventArgs e)
        {
            progressBar1.PerformStep();
           if (progressBar1.Value == 100) timer1.Stop();
        }

    }
}
